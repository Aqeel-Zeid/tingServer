package com.ting.tingServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TingServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TingServerApplication.class, args);
	}

}
